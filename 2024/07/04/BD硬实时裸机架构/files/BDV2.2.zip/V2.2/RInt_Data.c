//RInt������
#include "global.h"
#include "BD_misc.h"
int RInt_ExD_Var1[AXISSUM];
float RInt_ExE_Var2[AXISSUM];

#include "BD_misc.h"
int mydata[AXISSUM][100];
int* RInt_Data[AXISSUM];
void RInt_Ctor()
{
	register int n = loop_nth[RInt];
	RInt_Data[n] = mydata[n];
}
#include "Dubhe_if.h"
#define EXNAME ExA
IN(RInt, int*, RInt_Data);
void test()
{
	int* mydata = ExAGet_RInt_Data(0);
	mydata[10] = 5;
}


//#include "BD_misc.h"
//typedef struct
//{
//	int array[100];
//}MyData;
//MyData _RInt_Data[AXISSUM];
//MyData* RInt_Data[AXISSUM];
//void RInt_Ctor()
//{
//	register int n = loop_nth[RInt];
//	RInt_Data[n] = &_RInt_Data[n];
//}
//
//#include "Dubhe_if.h"
//#define EXNAME ExA
//IN(RInt, MyData*, RInt_Data);
//void test()
//{
//	MyData* mydata = ExAGet_RInt_Data(0);
//	mydata->array[10] = 5;
//}


