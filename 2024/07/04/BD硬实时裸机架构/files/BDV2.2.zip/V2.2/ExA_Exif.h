#ifndef EXA_IF_H
#define EXA_IF_H
#include "BD_EXif.h"
#define EXNAME EXA
EX_OUT(RInt, float, RInt_ExE_Var2);
EX_INOUT(HInt, int, HInt_ExB_Var1);
EX_OUT_ALL(RInt, int, xsss, 2);
EX_IN_ALL_WEAK(HInt, int, HInt_ExC_Null, 3);
EX_IN(RInt, int, RInt_ExD_Var1);
EX_OUT(RInt, float, RInt_ExE_Var2);
//extern float RInt_ExE_Var2[];
#endif // !EXA_IF_H


