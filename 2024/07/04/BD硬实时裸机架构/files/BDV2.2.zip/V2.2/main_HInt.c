#include "main_pvt.h"
void HInt_Main()
{
	for (loop_nth[HInt] = 0; loop_nth[HInt] < AXISSUM; loop_nth[HInt]++)
	{
		Hint_ExA(exa[loop_nth[HInt]]);
		//Hint_ExB(exb[loop_nth[HInt]]);
	}
}