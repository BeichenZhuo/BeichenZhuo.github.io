#include "main_pvt.h"
void Ctor_Main()
{
	for (loop_nth[Ctor] = 0; loop_nth[Ctor] < AXISSUM; loop_nth[Ctor]++)
	{
		exa[loop_nth[Ctor]] = Ctor_ExA();
		//exb[loop_nth[Ctor]] = Ctor_ExB();
	}
}
void Init_Main()
{
	for (loop_nth[Init] = 0; loop_nth[Init] < AXISSUM; loop_nth[Init]++)
	{
		Init_ExA(exa[loop_nth[Init]]);
		//Init_ExB(exb[loop_nth[Init]]);
	}
}
