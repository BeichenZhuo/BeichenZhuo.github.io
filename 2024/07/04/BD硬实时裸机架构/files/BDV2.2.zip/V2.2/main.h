#ifndef MAIN_H
#define MAIN_H
void Ctor_Main();
void Init_Main();
void HInt_Main();
void RInt_Main();
#endif // !MAIN_H