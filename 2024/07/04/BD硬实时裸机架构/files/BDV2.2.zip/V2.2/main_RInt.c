#include "main_pvt.h"
void RInt_Main()
{
	for (loop_nth[RInt] = 0; loop_nth[RInt] < AXISSUM; loop_nth[RInt]++)
	{
		Rint_ExA(exa[loop_nth[RInt]]);
		//Rint_ExB(exb[loop_nth[RInt]]);
	}
}