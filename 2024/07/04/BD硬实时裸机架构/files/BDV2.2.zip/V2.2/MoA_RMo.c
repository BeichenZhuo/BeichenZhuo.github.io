#include "MoA_Mopvt.h"
void RInt_MoA_Func123(void* mo)
{
	MoA* me = (MoA*)mo;
	me->b = RIntMOAGet_RInt_ExD_Var1();
	RIntMOASet_RInt_ExE_Var2(me->a);
	me->a = Func3(1, 2);
}