#ifndef GLOBAL_H
#define GLOBAL_H
#define AXISSUM 2
#endif // !GLOBAL_H

