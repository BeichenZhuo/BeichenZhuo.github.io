#ifndef MAIN_PVT_H
#define MAIN_PVT_H

#include "BD_misc.h"
#include "global.h"
//�����ڲ�����
#include "ExA_Ex.h"
extern void* exa[];
//#include "ExB.h"
//extern void* exb[];

#endif // !MAIN_PVT_H
