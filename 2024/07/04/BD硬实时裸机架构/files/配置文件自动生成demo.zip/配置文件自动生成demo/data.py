import os
import re


class Module:
    def __init__(self):
        self.name = None
        self.inputVar = {}
        self.outputVar = {}
        self.file = ''
    
    def __eq__(self, other):
        if self.name == other.name:
            return True
        else:
            return False

class Instance:
    def __init__(self):
        self.name = None
        self.module = Module()
        self.linkInput = {}
        self.linkOutput = {}
        self.priority = (0, 0, 0)

    def __eq__(self, other):
        if (self.name == other.name) and (self.module.name == other.module.name):
            return True
        else:
            return False

      
    def ModuleExist(self, mdic):
        if self.module.name in mdic.keys():
            return True
        else:
            return False

class ReadLine:
    @staticmethod
    def ReadImport(line):
        module = re.search('IMPORT\((\w*)\)', line)
        if module:
            return module.groups()[0]
        else:
            return None
    
    @staticmethod
    def ReadModule(line):
        module = re.search('MODULE\((\w*)\)', line)
        if module:
            return module.groups()[0]
        else:
            return None

    @staticmethod
    def ReadInputVar(line):
        input = re.search('INPUTVAR\((\w*),\s*(\w*)\)', line)
        if input:
            return {input.groups()[0]: input.groups()[1]}
        else:
            return None

    @staticmethod
    def ReadOutputVar(line):
        output = re.search('OUTPUTVAR\((\w*),\s*(\w*)\)', line)
        if output:
            return {output.groups()[0]: output.groups()[1]}
        else:
            return None
    
    @staticmethod
    def ReadInstance(line):
        res = re.search('CREATE\((\w*),\s*(\w*)\)', line)
        if res:
            return (res.groups()[0], res.groups()[1])
        else:
            return None

    @staticmethod
    def ReadLinkInput(line):
        input = re.search('LINKINPUT\((\w*),\s*([\w\[\]]*)\)', line)
        if input:
            return {input.groups()[0]: input.groups()[1]}
        else:
            return None

    @staticmethod
    def ReadLinkOutput(line):
        output = re.search('LINKOUTPUT\((\w*),\s*([\w\[\]]*)\)', line)
        if output:
            return {output.groups()[0]: output.groups()[1]}
        else:
            return None

    @staticmethod
    def ReadPriority(line):
        output = re.search('PRIORITY\((\d*),\s*(\d*),\s*(\d*)\)', line)
        if output:
            return (output.groups()[0], output.groups()[1], output.groups()[2])
        else:
            return None

class GetModules:
    Modules = {}

    @staticmethod
    def GetModule(file):
        m = Module()
        with open(file) as f:
            for line in f:
                name = ReadLine.ReadModule(line)
                if name:
                    if m.name:
                        m.file = file
                        GetModules.Modules.update({m.name: m})
                        m = Module()
                    m.name = name
                if m.name:
                    input = ReadLine.ReadInputVar(line)
                    if input:
                        m.inputVar.update(input)
                    output = ReadLine.ReadOutputVar(line)
                    if output:
                        m.outputVar.update(output)
        if m.name:
            m.file = file
            GetModules.Modules.update({m.name: m})

class GetInstances:
    Instances = []

    @staticmethod
    def GetInstance(file):
        m = Instance()
        with open(file) as f:
            for line in f:
                module = ReadLine.ReadInstance(line)
                if module:
                    if m.name:
                        m.file = file
                        GetInstances.Instances.append(m)
                        m = Instance()
                    m.name = module[1]
                    m.module.name = module[0]
                if m.name:
                    input = ReadLine.ReadLinkInput(line)
                    if input:
                        m.linkInput.update(input)
                    output = ReadLine.ReadLinkOutput(line)
                    if output:
                        m.linkOutput.update(output)
                    prio = ReadLine.ReadPriority(line)
                    if prio:
                        m.priority = prio
        if m.name:
            m.file = file
            GetInstances.Instances.append(m)

class Files:
    ZBCfiles = []
    InstanceZBCfiles = []
    @staticmethod
    def GetAllZBC(dir):
        files = os.listdir(dir)
        for file in files:
            cur = os.path.join(dir, file)
            if os.path.isdir(cur):
                Files.GetAllZBC(cur)
            else:
                if cur.endswith('zbc'):
                    Files.ZBCfiles.append(cur)
    @staticmethod
    def CheckZBCExist(path):
        if os.path.exists(path):
            return True
        else:
            return False

    @staticmethod
    def ReadConfigFile(file):
        with open(file) as f:
            for line in f:
                res = ReadLine.ReadImport(line)
                if res:
                    if Files.CheckZBCExist(res + ".zbc"):
                        Files.InstanceZBCfiles.append(res + ".zbc")
                        Files.ReadConfigFile(res + ".zbc")
                    else:
                        print("不存在" + res + ".zbc")