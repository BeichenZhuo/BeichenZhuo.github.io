import os
import re

loop_set = ('FastMlp','SlowMlp','Mlp')
module_dic = {}
var_dic = {}
import_moudule_dic = {}

class Module:
    
    def __init__(self):
        self.name = None
        self.count = ''
        self.prio = {}
        self.RW = set()
        self.RO = set()
        self.WO = set()
        self.file = ''
    
    def __eq__(self, other):
        if self.name == other.name:
            return True
        else:
            return False
    
    def __hash__(self):
        return hash(self.name)
    
class VarLoopRW:
    def __init__(self):
        self.write_module = {} #{ModuleA: Uni}
        self.read_module = {}

class Var:
    def __init__(self):
        self.name = None
        self.loop = {} #{loop_set:VarLoopRW}
        self.type = ''
        
    def __eq__(self, other):
        if self.name == other.name and self.type == other.type:
            return True
        else:
            return False

    def __hash__(self):
        return hash(self.name) + hash(self.type)


class ReadLine:
    @staticmethod
    def __ProcessFileString(file):
        if os.path.exists(file):
            with open(file) as f:
                str = f.read()
                bds = '//.*|\/\*(?:[^\*]|\*+[^\/\*])*\*+\/|\s+'
                target = re.compile(bds)
                return target.sub(' ',str)
        print("文件错误，文件%s不存在"%file)
        return None
        
    @staticmethod
    def ReadModule(file):
        module = Module()
        if not file.strip().endswith("ex.h"):
            print("文件错误，文件%s不是模块文件"%file)
            return False
        module.file = file
        data = ReadLine.__ProcessFileString(file)
        if data:
            #文件有内容
            bds = '#define\s+name\s+(\w+)'
            target = re.compile(bds)
            res = target.search(data)
            if res:
                #存在模块
                #如果存在多个定义，只看第一个
                module.name = res.groups()[0]
                if(module.name in module_dic.keys()):
                    print("模块错误，已经存在%s模块"%module.name)
                    return False
                else:
                    module_dic.update({module.name: module})
            else:
                print("模块错误，文件不存在模块声明，应该使用格式#define name ModuleA")
                return False
            bds = '([A-Za-z0-9]+)_(RO|RW|WO)_((?:Uni|Ins|All)(?:_Weak)?)\s*\(\s*([^;]*)\s*,\s*([^;]*)\s*,\s*([^;]*)\s*\)'
            target = re.compile(bds)
            res = target.findall(data)
            for r in res:
                loop = r[0].replace(" ", "")
                if loop in loop_set:
                    #调度存在
                    datapool_var = r[5].strip()
                    bds = 'DataPool(\s*)\((\s*)(\w+)(\s*)\)'
                    target = re.compile(bds)
                    tem = target.search(datapool_var)
                    if tem:
                        datapool_var = tem.groups()[2]
                        if not (tem.groups()[0] == '' and tem.groups()[1] == '' and tem.groups()[3] == ''):
                            print('模块%s警告，格式为DataPool(var)，不应当有空格'%(module.name))       
                    else:
                        print('模块%s错误，%s变量定义错误，格式为DataPool(var)'%(module.name, datapool_var))
                        return False
                    #变量池变量名正常
                    vtype = r[3].replace(" ", "")
                    if datapool_var in var_dic.keys():
                        var = var_dic[datapool_var]
                        if not vtype == var.type:
                            print('变量%s错误，在模块%s中与%s类型冲突'%(var.name, module.name, var.type))
                            return False
                    else:
                        var = Var()
                        var.name = datapool_var
                        var.type = vtype
                        var_dic.update({var.name: var})
                    module_var = r[4].replace(" ", "")
                    RW = r[1].replace(" ", "")
                    UAI = r[2].replace(" ", "")
                    if RW == 'RO':
                        module.RO.add(module_var)
                        if not (loop in var.loop.keys()):
                            var.loop.update({loop:VarLoopRW()})
                        var.loop[loop].read_module.update({module.name: UAI})
                    elif RW == 'RW':
                        module.RW.add(module_var)
                        if not (loop in var.loop.keys()):
                            var.loop.update({loop:VarLoopRW()})
                        var.loop[loop].write_module.update({module.name: UAI})
                        var.loop[loop].read_module.update({module.name: UAI})
                    elif RW == 'WO':
                        module.WO.add(module_var)
                        if not (loop in var.loop.keys()):
                            var.loop.update({loop:VarLoopRW()})
                        var.loop[loop].write_module.update({module.name: UAI})
                else:
                    print('模块%s警告，调度%s不存在'%(module.name, loop))
            return True
        else:
            return False
        return False


    @staticmethod
    def ReadImport(file):
        data = ReadLine.__ProcessFileString(file)
        if data:
            bds = 'Import_Module\s*\(\s*(\w*)\s*,\s*(\w*)\s*\);'
            target = re.compile(bds)
            res = target.findall(data)
            for r in res:
                m = r[0].replace(" ", "")
                if m in module_dic.keys():
                    import_moudule_dic.update({m: module_dic[m]})
                    module_dic[m].count = r[1].replace(" ", "")
                else:
                    print("错误，不存在模块%s"%m)
                    return False
            return True
        else:
            return False
        return False

    @staticmethod
    def ReadInputVar(line):
        input = re.search('INPUTVAR\((\w*),\s*(\w*)\)', line)
        if input:
            return {input.groups()[0]: input.groups()[1]}
        else:
            return None

    @staticmethod
    def ReadOutputVar(line):
        output = re.search('OUTPUTVAR\((\w*),\s*(\w*)\)', line)
        if output:
            return {output.groups()[0]: output.groups()[1]}
        else:
            return None
    
    @staticmethod
    def ReadInstance(line):
        res = re.search('CREATE\((\w*),\s*(\w*)\)', line)
        if res:
            return (res.groups()[0], res.groups()[1])
        else:
            return None

    @staticmethod
    def ReadLinkInput(line):
        input = re.search('LINKINPUT\((\w*),\s*([\w\[\]]*)\)', line)
        if input:
            return {input.groups()[0]: input.groups()[1]}
        else:
            return None

    @staticmethod
    def ReadLinkOutput(line):
        output = re.search('LINKOUTPUT\((\w*),\s*([\w\[\]]*)\)', line)
        if output:
            return {output.groups()[0]: output.groups()[1]}
        else:
            return None

    @staticmethod
    def ReadPriority(line):
        output = re.search('PRIORITY\((\d*),\s*(\d*),\s*(\d*)\)', line)
        if output:
            return (output.groups()[0], output.groups()[1], output.groups()[2])
        else:
            return None