from new_data import *
import re

res = ReadLine.ReadModule("ModuleB_ex.h")
ReadLine.ReadImport("ModuleB_ex.h")
pass
pass