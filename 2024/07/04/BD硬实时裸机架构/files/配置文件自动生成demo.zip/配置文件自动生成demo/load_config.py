import os
import sys
from data import Files
from data import GetInstances
from data import GetModules

Files.GetAllZBC(os.path.curdir)
for f in Files.ZBCfiles:
    GetModules.GetModule(f)
    #os.system("python create_c.py " + f)
    os.system("python create_h.py " + f)

#for file in sys.argv[1:]:
#    Files.ReadConfigFile(file)
Files.ReadConfigFile("bigbigfun1.zbc")

for f in Files.InstanceZBCfiles:
    GetInstances.GetInstance(f)
    os.system("python create_instance.py " + f)

for inst in GetInstances.Instances:
    if inst.ModuleExist(GetModules.Modules):
        inst.module = GetModules.Modules[inst.module.name]
    else:
        GetInstances.Instances.remove(inst)
        print("不存在" + inst.module.name + "," + inst.module.name + inst.name + "无法创建！\n")
        exit()

for inst in GetInstances.Instances:
    for input in inst.linkInput:
        if input not in inst.module.inputVar.keys():
            GetInstances.Instances.remove(inst)
            print(inst.module.name + "不存在输入变量" + input + "," + inst.module.name + inst.name + "无法创建！\n")
            exit()

for inst in GetInstances.Instances:
    for output in inst.linkOutput:
        if output not in inst.module.outputVar.keys():
            GetInstances.Instances.remove(inst)
            print(inst.module.name + "不存在输出变量" + output + "," + inst.module.name + inst.name + "无法创建！\n")
            exit()
header = open("Schedule.c", 'w')
for inst in GetInstances.Instances:

    header.write("extern " + "Module " + inst.module.name + "_" + inst.name + ";\n")

header.write("\nint Init()\n{\n")
for inst in GetInstances.Instances:
    header.write("\tif(!Init_" + inst.module.name + "(&" + inst.module.name + "_" + inst.name +")) return 0;\n")
header.write("\treturn 1;\n}\n")

header.write("\nvoid FastLoop()\n{\n")
#FastLoop排序
GetInstances.Instances.sort(key=lambda x:x.priority[0], reverse=False)
for inst in GetInstances.Instances:
    header.write("\tFastLoop_" + inst.module.name + "(&" + inst.module.name + "_" + inst.name +");\n")
header.write("}\n")

header.write("\nvoid SlowLoop()\n{\n")
#SlowLoop排序
GetInstances.Instances.sort(key=lambda x:x.priority[1], reverse=False)
for inst in GetInstances.Instances:
    header.write("\tSlowLoop_" + inst.module.name + "(&" + inst.module.name + "_" + inst.name +");\n")
header.write("}\n")

header.write("\nvoid MainLoop()\n{\n")
#MainLoop排序
GetInstances.Instances.sort(key=lambda x:x.priority[2], reverse=False)
for inst in GetInstances.Instances:
    header.write("\tMainLoop_" + inst.module.name + "(&" + inst.module.name + "_" + inst.name +");\n")
header.write("}\n")