extern Module m4_b1;
extern Module ModuleB_f1;
extern Module ModuleA_f1;

int Init()
{
	if(!Init_m4(&m4_b1)) return 0;
	if(!Init_ModuleB(&ModuleB_f1)) return 0;
	if(!Init_ModuleA(&ModuleA_f1)) return 0;
	return 1;
}

void FastLoop()
{
	FastLoop_ModuleA(&ModuleA_f1);
	FastLoop_ModuleB(&ModuleB_f1);
	FastLoop_m4(&m4_b1);
}

void SlowLoop()
{
	SlowLoop_ModuleB(&ModuleB_f1);
	SlowLoop_ModuleA(&ModuleA_f1);
	SlowLoop_m4(&m4_b1);
}

void MainLoop()
{
	MainLoop_ModuleB(&ModuleB_f1);
	MainLoop_ModuleA(&ModuleA_f1);
	MainLoop_m4(&m4_b1);
}
